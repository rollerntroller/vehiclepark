<?php
$con=mysqli_connect("dublinvehicl.cy0nam0gijjl.us-east-1.rds.amazonaws.com", "admin", "admin123", "vpmsdb");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
